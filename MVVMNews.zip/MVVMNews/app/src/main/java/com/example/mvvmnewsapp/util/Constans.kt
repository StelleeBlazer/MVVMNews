package com.example.mvvmnewsapp.util

class Constans {
    companion object {
        const val API_KEY = "6d3f69d06baf4025a8d5dc3daf5aa0e6"
        const val BASE_URL = "https://newsapi.org/"
        const val QUERY_PAGE_SIZE = 20
    }
}