package com.example.mvvmnewsapp

import android.app.Application

class NewsApplication : Application()