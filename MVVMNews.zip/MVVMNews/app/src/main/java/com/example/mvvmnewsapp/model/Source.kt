package com.example.mvvmnewsapp.model

data class Source(
    val id: Any,
    val name: String
)